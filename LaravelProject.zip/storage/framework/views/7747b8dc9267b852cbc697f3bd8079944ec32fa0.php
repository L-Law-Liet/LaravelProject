<?php $__env->startSection('head'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="<?php echo e(asset('public/css/login.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('public/js/news.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-5 pt-5">
        <?php if($message = Session::get('error')): ?>
            <div class="alert alert-danger d-block">
                <button type="button" class="close">x</button>
                <strong><?php echo e($message); ?></strong>
            </div>
            <?php endif; ?>
        <div class="d-flex justify-content-center">
            <form class="box text-center align-text-bottom mb-2" action="<?php echo e(route('login')); ?>" method="post" novalidate>
                <?php echo csrf_field(); ?>
                <div class="Head mt-2">
                    <svg height="60" width="300" xmlns="http://www.w3.org/2000/svg">
                        <rect class="shape1" height="60" width="300" />
                        <rect class="shape2" height="60" width="300" />
                    </svg>
                    <img class="L d-inline" src="<?php echo e(asset('public/img/L.png')); ?>" alt="L">
                    <h1 class="LOGIN d-inline">OGIN</h1>
                </div>
                <input type="text" name="email" placeholder="Username" value="<?php echo e(Request::old('email')?:''); ?>">
                <?php if($errors->has('email')): ?>
                    <span class="text-danger">
                                    <?php echo e($errors->first('email')); ?>

                                </span>
                <?php endif; ?>
                <input type="Password" name="password" placeholder="Password">
                <?php if($errors->has('password')): ?>
                    <span class="text-danger">
                                    <?php echo e($errors->first('password')); ?>

                                </span>
                <?php endif; ?>

                <p style="font-size: 14px; color: tomato; margin: 5px">

                </p>
                <div>
                    <input type="submit" name="login" value="LOGIN">
                </div>
                <div>
                    <a class="text-decoration-none" href="">Forgot the password?</a>
                </div>
                <div class="mt-2">
                    <a class="text-decoration-none text-warning" href="<?php echo e(url('signup')); ?>">Don't have an account?</a>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\LaravelProject\resources\views/login.blade.php ENDPATH**/ ?>
