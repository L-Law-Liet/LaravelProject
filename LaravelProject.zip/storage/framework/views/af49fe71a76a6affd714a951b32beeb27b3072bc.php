<?php $__env->startSection('head'); ?>
<link href="<?php echo e(asset('public/css/welcome.css')); ?>" rel="stylesheet">
<script type="text/javascript" src="<?php echo e(asset('public/js/welcome.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

       <div class="d-flex justify-content-center m-2 p-2">
           <div class="card bg-light">
               <div class="card-body rounded-lg">
                   <div class="m-4">
                       <img src="<?php echo e(asset('public/img/s1.jpg')); ?>" alt="">
                   </div>
                   <div class="m-4">
                       <img src="<?php echo e(asset('public/img/s2.jpg')); ?>" alt="">
                   </div>
                   <div class="m-4">
                       <img src="<?php echo e(asset('public/img/s3.jpg')); ?>" alt="">
                   </div>
               </div>
           </div>
       </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\LaravelProject\resources\views/home/home.blade.php ENDPATH**/ ?>
