<?php $__env->startSection('head'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/signup.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="m-5 p-5 text-center">
        <div class="justify-content-center d-flex">
            <div class="content">
                <div id="regform">
                    <div class="Head">
                        <svg height="50" width="300" xmlns="http://www.w3.org/2000/svg">
                            <rect class="shape1" height="50" width="300" />
                            <rect class="shape2" height="50" width="300" />
                        </svg>
                        <h5>Sign up now</h5>
                    </div>
                    <form action="<?php echo e(route('register')); ?>" method="post" novalidate>
                        <?php echo csrf_field(); ?>
                        <div>
                            <input class="t <?php echo e($errors->has('firstname') ? 'border border-danger' : ''); ?>" type="text"
                                   placeholder="First Name" name="firstname" autocomplete="on" value="<?php echo e(Request::old('firstname')?:''); ?>" maxlength="20">
                            <?php if($errors->has('firstname')): ?>
                                <span class="text-danger">
                                    <?php echo e($errors->first('firstname')); ?>

                                </span>
                            <?php endif; ?>
                            <input class="t mt-3 <?php echo e($errors->has('lastname') ? 'border border-danger' : ''); ?>" type="text"
                                   placeholder="Last Name" name="lastname" autocomplete="on" value="<?php echo e(Request::old('lastname')?:''); ?>" maxlength="20">
                            <?php if($errors->has('lastname')): ?>
                                <span class="text-danger">
                                    <?php echo e($errors->first('lastname')); ?>

                                </span>
                            <?php endif; ?>
                            <input class="t mt-3 <?php echo e($errors->has('email') ? 'border border-danger' : ''); ?>" type="email"
                                   placeholder="E-mail" name="email" autocomplete="on" value="<?php echo e(Request::old('email')?:''); ?>" maxlength="30">
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger">
                                    <?php echo e($errors->first('email')); ?>

                                </span>
                            <?php endif; ?>
                            <input class="t mt-3 <?php echo e($errors->has('phone') ? 'border border-danger' : ''); ?>" type="tel" autocomplete="on"  name="phone"
                                   placeholder="8-777-444-4774" pattern="[8]{1}[0-9]{3}[0-9]{3}[0-9]{4}" required value="<?php echo e(Request::old('phone')?:''); ?>" maxlength="11">
                            <?php if($errors->has('phone')): ?>
                                <span class="text-danger">
                                    <?php echo e($errors->first('phone')); ?>

                                </span>
                            <?php endif; ?>
                            <input class="t mt-3 <?php echo e($errors->has('password') ? 'border border-danger' : ''); ?>" type="password" placeholder="Password" name="password" maxlength="20">
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger">
                                    <?php echo e($errors->first('password')); ?>

                                </span>
                            <?php endif; ?>
                            <input class="t mt-3 <?php echo e($errors->has('password_confirmation') ? 'border border-danger' : ''); ?>" type="password" placeholder="Confirm the password" name="password_confirmation" maxlength="20">
                            <?php if($errors->has('password_confirmation')): ?>
                                <span class="text-danger">
                                    <?php echo e($errors->first('password_confirmation')); ?>

                                </span>
                            <?php endif; ?>
                            <p class="log mt-3">I agree to <a class="log text-decoration-none text-warning" href="#"> terms and conditions</a></p>
                        </div>
                        <div>
                            <input id="btn" type="submit" value="Register" name="r">
                        </div>
                        <div>
                            <a class="text-decoration-none text-warning" id="old" href="<?php echo e(url('login')); ?>">Already have an account?</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\LaravelProject\resources\views/auth/register.blade.php ENDPATH**/ ?>