<nav>
    <div class="bg-dark d-flex justify-content-center">
        <ul class="nav">
            <li class="nav-link m-1 mr-3 ml-3"><a class="text-decoration-none text-light" href="<?php echo e(url('/')); ?>">Home
                    <img class="ml-1 mb-1" src="<?php echo e(asset(url('img/home.svg'))); ?>" alt=""></a></li>
            <li class="nav-link m-1 mr-3 ml-3"><a class="text-decoration-none text-light" href="<?php echo e(url('news')); ?>">News
                    <img class="ml-1 mb-1" src="<?php echo e(asset(url('img/news.svg'))); ?>" alt=""></a></li>
            <li class="nav-link m-1 mr-3 ml-3"><a class="text-decoration-none text-light" href="<?php echo e(url('sale')); ?>">Sale
            <img class="ml-1 mb-1" src="<?php echo e(asset(url('img/sale.svg'))); ?>" alt=""></a></li>
        <?php if(Auth::check() && !Auth::user()->isAdmin): ?>
                <li class="nav-link m-1 mr-3 ml-3"><a class="text-decoration-none text-light" href="<?php echo e(url('favourites')); ?>">Favourites
                        <img class="ml-1 mb-1" src="<?php echo e(asset(url('img/star.svg'))); ?>" alt=""></a></li>
                <li class="nav-link m-1 mr-3 ml-3"><a class="text-decoration-none text-light" href="<?php echo e(url('basket')); ?>">
                        Basket <img class="ml-1 mb-1" src="<?php echo e(asset(url('img/cart.svg'))); ?>" alt="">
                    </a></li>
               <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item m-1 mr-3 ml-3">
                    <a class="nav-link text-light" href="<?php echo e(url('login')); ?>"><?php echo e(__('Login')); ?>

                        <img class="ml-1 mb-1" src="<?php echo e(asset(url('img/login.svg'))); ?>" alt=""></a>
                </li>
                <?php if(Route::has('register')): ?>
                    <li class="nav-item m-1 mr-3 ml-3">
                        <a class="nav-link text-light" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?>

                            <img class="ml-1 mb-1" src="<?php echo e(asset(url('img/add.svg'))); ?>" alt=""></a>
                    </li>
                <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown  m-1 mr-3 ml-3">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->firstname); ?> <span class="caret"></span>
                    </a>

                    <div class="DropDown dropdown-menu dropdown-menu-right bg-dark" aria-labelledby="navbarDropdown">
                        <a class="Item d-block p-1 bg-dark text-decoration-none text-light" href="<?php echo e(url('profile')); ?>">
                            <i class="fa fa-user m-1" style="font-size: 22px"></i>
                            <?php echo e(__('Profile')); ?>

                        </a>
                        <a class="Item d-block p-1 bg-dark text-decoration-none text-light" href="<?php echo e(route('logout')); ?>"
                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <img class="ml-1 mb-1" src="<?php echo e(asset(url('img/logout.svg'))); ?>" alt="">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>
            <li><div class="nav-link m-1 mr-3 ml-3"><div class="text-decoration-none text-light dropdown-toggle"
                 data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="cursor: pointer">Categories
                    <img class="ml-1 mb-1" src="<?php echo e(asset(url('img/grid.svg'))); ?>" alt=""></div>
                    <div class="mt-2 dropdown-menu bg-dark">
                        <?php if(count($categories)>0): ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="d-block p-1 bg-dark text-decoration-none dropdown-item text-light" href="<?php echo e(url('category', $c->id)); ?>">
                                    <img class="mr-1 mb-1" src="<?php echo e(asset('img/'.strtolower($c->name).'.svg')); ?>" alt=""><?php echo e($c->name); ?>

                                    </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <a class="Item d-block p-1 bg-dark text-decoration-none text-light" href="<?php echo e(url('category')); ?>">
                            <img class="mr-1 mb-1" src="<?php echo e(asset('img/viral.svg')); ?>" alt="">All Categories</a>

                    </div>
                </div>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH W:\LaravelProject\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>