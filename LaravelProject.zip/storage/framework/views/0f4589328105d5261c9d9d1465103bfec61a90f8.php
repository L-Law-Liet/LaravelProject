<?

use App\Models\Category;

$categories = Category::all();
?>
    <!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="<?php echo e(asset('public/js/app.js')); ?>" defer></script>
    <link href="<?php echo e(asset('public/css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('public/bootstrap-component/css/bootstrap.min.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('public/img/icon.png')); ?>">
    <script src="<?php echo e(asset('public/bootstrap-component/js/jquery.min.js')); ?>"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="<?php echo e(asset('public/bootstrap-component/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="<?php echo e(asset('public/bootstrap-component/js/bootstrap.min.js')); ?>"></script>

    <style>
        .nav img{
            width: 20px;
            height: 20px;
        }
        .nav li, .Drop{
            font-size: 18px;
        }
        html {
            overflow: scroll;
            overflow-x: hidden;
        }
        ::-webkit-scrollbar {
            width: 0;  /* Remove scrollbar space */
            background: transparent;  /* Optional: just make scrollbar invisible */
        }
        /* Optional: show position indicator in red */
        ::-webkit-scrollbar-thumb {
            background: #FF0000;
        }
        footer {
            flex: 0 0 auto;
        }
    </style>
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body style="background-color: lightblue; background-image: linear-gradient(to bottom right, lightblue, lightgreen);">
<?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Start your project here-->
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="<?php echo e(asset('public/bootstrap-component/js/mdb.min.js')); ?>"></script>
<!-- Your custom scripts (optional) -->
<script type="text/javascript"></script>

</body>
</html>
<?php /**PATH D:\Open Server\LaravelProject\resources\views/layouts/main.blade.php ENDPATH**/ ?>
