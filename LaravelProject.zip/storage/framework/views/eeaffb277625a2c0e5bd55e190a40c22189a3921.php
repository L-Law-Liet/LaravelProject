<?php echo e($slot); ?>

<?php /**PATH W:\LaravelProject\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>