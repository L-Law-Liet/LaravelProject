<?php $__env->startSection('head'); ?>
    <title>Category</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/category.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100">
    <?php if(session()->has('ms')): ?>
        <div class="justify-content-center d-flex">
            <h4 class="bg-primary text-center align-middle text-white m-4 p-3 w-50 rounded-lg position-absolute" id="M1"
                style="opacity: 80%; z-index: 10;"><?php echo e(session()->get('ms')); ?></h4>
        </div>
    <?php endif; ?>
    <div class="m-4">
        <h1 class="h1d text-center font-weight-bold rounded-lg p-2 m-4">
            <?php if($category == ''): ?>
                All Categories
            <?php else: ?>
                <?php echo e($category->name); ?>

            <?php endif; ?>
        </h1>
    </div>
        <div class="container h-100">
            <div class="d-flex justify-content-center h-100">
                <div class="searchbar bg-light">
                    <input class="search_input" type="text" id="search" placeholder="Product Name">
                    <a class="search_icon"><img src="<?php echo e(asset('img/search.svg')); ?>" alt=""></a>
                </div>
            </div>
        </div>

    <div class="justify-content-center d-flex">
        <div class="w-75 rounded-lg mt-5">
            <div class="card mr-5 ml-5 p-3">
                <form action="<?php echo e((!empty($category->id)) ? url('category', $category->id) : url('category')); ?>" method="get">
                    <div class="input-group">
                        <h4 class="font-weight-normal mr-1">Sorting: </h4>
                        <select name="sort" class="custom-select">
                            <option <?php echo e(($SortType == 'default')? 'selected' : ''); ?> class="additional-option" value="default">Default</option>
                            <option <?php echo e(($SortType == 'pricea')? 'selected' : ''); ?> value="pricea">Price Ascending</option>
                            <option <?php echo e(($SortType == 'priced')? 'selected' : ''); ?> value="priced">Price Descending</option>
                            <option <?php echo e(($SortType == 'az')? 'selected' : ''); ?> value="az">A → Z</option>
                            <option <?php echo e(($SortType == 'za')? 'selected' : ''); ?> value="za">Z → A</option>
                            <option <?php echo e(($SortType == 'new')? 'selected' : ''); ?> value="new">New items</option>
                        </select>
                        <div class="input-group-append ml-1">
                            <input type="submit" class="btn btn-outline-primary" value="Apply">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php if($admin): ?>
        <button onclick="window.location='<?php echo e(url('product/add')); ?>'" class="position-fixed btn btn-success col-1 m-1">
            <img src="<?php echo e(asset('img/plus-circle.svg')); ?>" alt="+"> Add a Product</button>
       <?php endif; ?>
    <div class="d-flex justify-content-center">

        <?php if(session()->has('m')): ?>
            <div id="M" style="min-height: 30px; opacity: 80%; z-index: 10;"
                 class="bg-danger text-center text-white m-4 w-50 rounded-lg position-fixed">
                <h4>Product Deleted</h4>
            </div>
        <?php endif; ?>
        <div class="w-75">
            <?php if(count($products)>0): ?>
                <div id="ns">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="Inner" class="card bg-light card-body m-5">
                            <div class="row">
                                <div class="col-7 m-2">
                                    <div class="m-1">
                                        <h3 class="btn-outline-primary btn w-100 border-right-0 border-left-0 rounded-0 btn-lg"
                                            onclick="window.location='<?php echo e(url("product-details", $p->id)); ?>'"><?php echo e($p->name); ?></h3>
                                    </div>
                                    <div class="m-1"><h4>Category: <?php echo e($p->category); ?></h4></div>
                                    <div class="m-1"><h5>Price: $<?php echo e($p->price); ?></h5></div>
                                    <div class="card card-body bg-light m-1">
                                        <h6 class="text-center">Description</h6>
                                        <article>
                                            <?php echo e($p->description); ?>

                                            <?php if(strlen($p->description)<50): ?>
                                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium aperiam
                                                asperiores at beatae consectetur cupiditate debitis delectus, dolorem enim, facilis
                                                impedit incidunt ipsa iusto laboriosam, laudantium molestiae odio omnis optio pariatur
                                                perspiciatis quasi quidem repudiandae sapiente ullam unde velit voluptatem?
                                            <?php endif; ?>
                                        </article>
                                    </div>

                                    <?php if($admin): ?>
                                        <div class="text-center mt-3 m-2 ">
                                            <div class="d-inline">
                                                <form class="d-inline" action="<?php echo e(action('ProductsController@destroy', $p->id)); ?>" method="post">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo e(csrf_field()); ?>

                                                    <button type="submit" class="btn btn-danger col-2">
                                                        <img src="<?php echo e(asset('img/trash.svg')); ?>" alt="">
                                                    </button>
                                                </form>
                                            </div>
                                            <div class="d-inline">
                                                <form class="d-inline" action="<?php echo e(url('product/edit', $p->id)); ?>" method="post">
                                                    <?php echo e(csrf_field()); ?>

                                                    <button class="btn btn-info col-2" type="submit">
                                                        <img src="<?php echo e(asset('img/edit.svg')); ?>" alt="">
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="align-middle col m-1">
                                    <div class="Image rounded-lg m-1"  onclick="window.location='<?php echo e(url("product-details", $p->id)); ?>'"
                                         style="background: url('<?php echo e(asset('img/'.$p->path)); ?>') no-repeat;">
                                    </div>
                                    <p class="m-2 border p-1 rounded-lg <?php echo e(($p->hasDiscount)?'Dper':''); ?>">Discount: <?php echo e($p->discount); ?>%</p>
                                    <p class="m-2 p-1 rounded-lg border  <?php echo e(($p->hasDiscount)?'Discount':''); ?>">
                                        Discount price: $<u><?php echo e($p->price-($p->discount*$p->price/100)); ?></u></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div id="page">
                    <?php echo e($products->links()); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
    setTimeout(fade_out, 3000);

    function fade_out() {
        $("#M").fadeOut().empty();
        $("#M1").fadeOut().empty();
    }
    $('#search').on('keyup', function () {
        $v = $(this).val();
        if($v.trim() != ''){
            $('#page').hide();
        }
        else $('#page').show();
        console.log('N');
           $.ajax({
               type : 'get',
               url : '<?php echo e(URL::to('/search', [(($category != '')?$category->name: 'WRRRFIIIS'), $SortType])); ?>',
               data : {'search': $v},
               success:function (data) {
                   $('#ns').html(data);
               }
           });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\LaravelProject\resources\views/category.blade.php ENDPATH**/ ?>