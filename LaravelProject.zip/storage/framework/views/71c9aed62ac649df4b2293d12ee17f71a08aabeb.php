<?php $__env->startSection('head'); ?>
    <title>Update</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/products.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="min-vh-100">
    <div class="d-flex justify-content-center">
        <?php if(session('m')): ?>
            <div id="M" style="min-height: 18px; opacity: 80%; z-index: 10;"
                 class="bg-primary text-center text-white m-4 w-50 rounded-lg position-absolute">
                <h4>Product Updated Successfully!</h4>
            </div>
            <?php endif; ?>
        <div class="col-8 m-5 border border-info rounded-lg bg-light ">
            <div class="m-3">
                <h1 class="h1d text-center rounded-lg p-2 m-4">Product Edit</h1>
            </div>
            <form action="<?php echo e(action('ProductsController@update', $product->id)); ?>"  method="post" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo e(csrf_field()); ?>

                <div>
                    <div class="rounded-lg border-info border p-1 m-3"><label class="col-2 font-weight-bold">Name: </label>
                        <input name="name" class="col-9 p-1 rounded-lg border bg-light d-inline" type="text" value="<?php echo e($product->name); ?>"></div>
                    <div class="rounded-lg border-info border p-1 m-3"><label class="col-2 font-weight-bold">Price: </label>
                        <input name="price" class="col-9 p-1 rounded-lg border bg-light d-inline" type="text" value="<?php echo e($product->price); ?>"></div>
                    <div class="rounded-lg border-info border p-3 m-3 text-center"><label class="col-2 font-weight-bold">Description: </label>
                        <textarea style="resize: none; height: 200px"  name="description" class="p-1 col rounded-lg d-block border bg-light"><?php echo e($product->description); ?></textarea></div>
                    <div class="rounded-lg border-info border p-1 m-3"><label class="col-2 font-weight-bold">Discount: </label><input name="discount" class="col-9 p-1 rounded-lg border bg-light d-inline" type="text" value="<?php echo e($product->discount); ?>"></div>
                    <div class="rounded-lg border-info border p-1 m-3"><label class="col-2 font-weight-bold">Category: </label><input name="category" class="col-9 p-1 rounded-lg border bg-light d-inline" type="text" value="<?php echo e($product->category); ?>"></div>
                    <div class="rounded-lg border-info border p-1 m-3"><label class="col-2 font-weight-bold">
                            <abbr class="text-decoration-none mark" title="JPG PNG JPEG">Image:</abbr>
                        </label><input name="image" class="col-8 p-1 rounded-lg border bg-light d-inline" type="file" accept=".jpg, .jpeg, .png, .gif"></div>
                </div>
                <div class="m-3 text-center">
                    <button type="submit" class="btn btn-success col-3"><img src="<?php echo e(asset('img/save.svg')); ?>" alt=""></button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    setTimeout(fade_out, 3000);

    function fade_out() {
        $("#M").fadeOut().empty();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\LaravelProject\resources\views/products.blade.php ENDPATH**/ ?>