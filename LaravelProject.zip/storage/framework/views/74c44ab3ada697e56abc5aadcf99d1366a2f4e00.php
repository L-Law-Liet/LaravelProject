<footer>
<div class="bg-dark text-warning text-center p-2">&copy Copyright 2020</div>
</footer>
<?php /**PATH W:\LaravelProject\resources\views/layouts/footer.blade.php ENDPATH**/ ?>