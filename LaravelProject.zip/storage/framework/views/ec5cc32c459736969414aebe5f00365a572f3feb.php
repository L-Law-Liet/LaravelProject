
<?php $__env->startSection('head'); ?>
    <title>News</title>
    <link href="<?php echo e(asset('css/news.css')); ?>" rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset('js/news.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div id="container1">
        <div id="container2">
            <div class="content">
                <?php $__currentLoopData = $News; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <section class="s"
                    style='background: url("<?php echo e(asset(url("img/news".(3-$k).".png"))); ?>") no-repeat;
                        background-size: cover;
                        width: 100%;
                        height: 100%;
                        overflow: hidden;
                        background-attachment: fixed;
                        display: flex;
                        justify-content: center;
                        align-items: center;'>
                        <h1 class="h1w text-light"><?php echo e($n); ?></h1>
                    </section>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\LaravelProject\resources\views/news.blade.php ENDPATH**/ ?>