<?php $__env->startSection('content'); ?>

    <button class="btn btn-outline-primary">GO</button>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\LaravelProject\resources\views/home/home.blade.php ENDPATH**/ ?>
