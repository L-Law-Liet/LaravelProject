<?php $__env->startSection('head'); ?>
    <title>Home</title>
<link href="<?php echo e(asset('public/css/welcome.css')); ?>" rel="stylesheet">
<script type="text/javascript" src="<?php echo e(asset('public/js/welcome.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1 class="text-center btn-primary rounded-lg p-2 m-4">In our store you will find</h1>
       <div class="d-flex justify-content-center m-2 p-2">
           <div class="card bg-light">
               <div class="card-body rounded-lg">
                  <?php $__currentLoopData = $ps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <div class="bg-info rounded-lg p-2 m-3">
                       <div class="m-4">
                           <h3 class="text-center btn-outline-warning mb-5 rounded-lg p-1" onclick="window.location='<?php echo e(url("product-details", $p['id'])); ?>'"><?php echo e($p['name']); ?></h3>
                           <img onclick="window.location='<?php echo e(url("product-details", $p['id'])); ?>'" class="rounded-lg" src="<?php echo e(asset('public/img/'. $p['path'])); ?>" alt="">
                       </div>
                   </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </div>
           </div>
       </div>
    <h1 onclick="window.location='<?php echo e(url('category')); ?>'" class="text-center btn-primary rounded-lg p-2 m-4">Click to More...</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Open Server\LaravelProject\resources\views/home/home.blade.php ENDPATH**/ ?>
