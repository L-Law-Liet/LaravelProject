
<?php $__env->startSection('head'); ?>
    <title>Home</title>
<link href="<?php echo e(asset('css/welcome.css')); ?>" rel="stylesheet">
<script type="text/javascript" src="<?php echo e(asset('js/welcome.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1 class="h1d text-center font-weight-bold rounded-lg p-2 m-4">In our store you will find</h1>
    <div class="m-5">
        <?$i = 0?>
        <?php $__currentLoopData = $ps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($i%2 == 0): ?>
                <div>
                <?php endif; ?>
            <div class="bg-light border rounded-lg p-2 m-3 <?php echo e(($i%2 == 0)? 'Dleft':'Dright'); ?>">
              <div>
                  <div class="m-4">
                      <div class="text-center mb-5 p-1">
                          <h4 class="font-weight-normal"><?php echo e($p->name); ?></h4></div>
                      <div class="Cont">
                        <div class="mb-4 <?php echo e(($i%2 == 0)? 'float-left': 'float-right'); ?>" style="width: 350px; height: 300px">
                          <div onclick="window.location='<?php echo e(url("product-details", $p->id)); ?>'" class="Img rounded-lg"
                               style="background: url('<?php echo e(asset('img/'. $p->path)); ?>') no-repeat"></div>
                        </div>
                        <div class="Art <?php echo e(($i%2 == 0)? 'float-left': 'float-right'); ?> position-absolute">
                           <article class="card p-2 rounded-lg text-center">
                               <h4><u>Description</u></h4>
                               <?php echo e((strlen($p->description)>600)?substr($p->description, 0, 600).'...':$p->description); ?>

                               <?php if(strlen($p->description)<50): ?>
                                   Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium aperiam
                                   asperiores at beatae consectetur cupiditate debitis delectus, dolorem enim, facilis
                                   impedit incidunt ipsa iusto laboriosam, laudantium molestiae odio omnis optio pariatur
                                   perspiciatis quasi quidem repudiandae sapiente ullam unde velit voluptatem?
                               <?php endif; ?>
                           </article>
                           <div class="Cost">
                               <h4 style="margin-top: 1%"
                                   class="border p-2 rounded-lg font-weight-normal
                            <?php echo e(($p->hasDiscount)? 'Discount': ''); ?>">
                                   Cost: $<?php echo e($p->price); ?></h4>
                           </div>
                        </div>
                      </div>
                  </div>
                  <div class="clearfix"></div>
                  <div class="Cont <?php echo e(($i%2 == 0)? 'ml-4': 'mr-4'); ?>">
                      <a id="Ref" href="<?php echo e(url("product-details", $p->id)); ?>"
                         class="btn p-2 rounded-lg text-decoration-none text-white">More >></a>
                  </div>
              </div>
            </div>
            <?php if($i%2 != 0): ?>
                <div class="clearfix"></div>
                <?php endif; ?>
                    <?php if($i%2 != 0): ?>
                        </div>
                            <?php endif; ?>
           <?$i++?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div id="container" class="justify-content-center d-flex" onclick="window.location='<?php echo e(url('category')); ?>'">
        <button class="border-0 m-3 p-3" id="Btn">
            <span id="arr" class="fa fa-angle-right" style="font-size: 25px"></span>
            <span id="word" style="font-size: 25px">More...</span>
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Open Server\LaravelProject\resources\views/home/home.blade.php ENDPATH**/ ?>