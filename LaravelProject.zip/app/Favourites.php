<?php

namespace App;

use App\Models\Product;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class Favourites extends Model
{
}
